نشر موقع دعوة معرض الأدوية اللاوصفية 2026 على GitHub Pages

1) سجّل الدخول إلى https://github.com
2) أنشئ مستودعاً جديداً (New repository).
3) سمّه otc-2026-invitation واجعله Public.
4) ارفع ملف index.html الموجود في هذا المجلد إلى المستودع (Add file > Upload files).
5) افتح Settings > Pages.
6) في Build and deployment اختر Deploy from a branch.
7) اختر Branch: main و Folder: /(root)، ثم Save.
8) انتظر قليلاً حتى يظهر رابط الموقع في صفحة Pages.

سيكون الرابط غالباً:
https://اسم-حسابك.github.io/otc-2026-invitation/

ملاحظة: لا تشارك بيانات دخول GitHub مع أي شخص. لا أستطيع نشره داخل حسابك دون تسجيل الدخول والصلاحيات من طرفك.
